import 'package:flutter/material.dart';
import 'package:flutter_blue/flutter_blue.dart';
import 'dart:async';
import 'dart:math';

class Screen2 extends StatefulWidget {
  const Screen2({Key? key}) : super(key: key);

  @override
  _Screen2State createState() => _Screen2State();
}

class _Screen2State extends State<Screen2> {
  bool check2 = false;
  FlutterBlue flutterBlue = FlutterBlue.instance;
  String feedback = "Tap to connect";
  int x = -1;
  Future<void> chawal () async {
    flutterBlue.scanResults.listen((results) {
      for (ScanResult dev in results) {
        print(dev.device.name);
      }
    });
  }

  Future<void> getDevices() async {
    //Stream results;
    // Start scanning
    flutterBlue.stopScan();
    print('heloo');
    await flutterBlue.startScan(timeout: Duration(seconds: 4));
    print('heloo1');
    flutterBlue.stopScan();
    print('heloo2');
    await chawal();
    //Future<List> devices = results.toList();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[350],
        image: DecorationImage(
          image: AssetImage('assets/watermark.png'),
          fit: BoxFit.fitWidth,
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        bottomNavigationBar: BottomAppBar (
          color: Colors.blue[700],
          child: Container(
            height: 60.0,
          ),
        ),
        appBar: AppBar(
          title: Text(
            'Motion App',
            style: TextStyle(
              fontSize: 20,
            ),
          ),
          centerTitle: true,
          elevation: 0.0,
        ),
        body: StreamBuilder<List<ScanResult>> (
          stream: flutterBlue.scanResults,
          builder: (c, snapshot) {
            return Column(
              children: snapshot.data!.map((e) {
                List<String> list = e.advertisementData.serviceUuids;
                bool check = false;
                for (int i = 0; i < list.length; i++) {
                  if (list[i] == "4401188a-1ad8-11ec-9621-0242ac130002") {
                    x = i;
                    check = true;
                    check2 = true;
                    break;
                  }
                }
                if (check) {
                  return Row(
                    children: [
                      Expanded(
                        child: Card(
                          child: ListTile(
                            subtitle: Text(
                              feedback,
                              style: TextStyle(
                                fontSize: 10,
                                color: Colors.black,
                              ),
                            ),
                            isThreeLine: false,
                            minVerticalPadding: 25,
                            onTap: () async {
                              setState(() {
                                feedback = "Connecting....";
                              });
                              await e.device.connect(autoConnect: false);
                              List<BluetoothDevice> obj = await flutterBlue
                                  .connectedDevices;
                              if (obj[0] == e.device) {
                                feedback = "Connected";
                                setState(() { });
                                await Navigator.pushNamed(
                                  context, '/screen3', arguments: {
                                    'device': obj[0],
                                  }
                                );
                                await e.device.disconnect();
                                feedback = "Tap to connect";
                                setState(() {  });
                              }
                              else {
                                print("not working");
                              }
                            },
                            title: Text(
                              e.device.name,
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                }
                else if (!check2) {
                  return Padding(
                    padding: const EdgeInsets.fromLTRB(0, 300, 0, 0),
                    child: Center(
                      child: Text(
                        'No Device Found !!!',
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  );
                }
                else {
                  return SizedBox.shrink();
                }
              }
              ).toList(),
            );
          }
        ),

        floatingActionButton: Container(
          height: 80,
          width: 80,
          decoration: BoxDecoration(
            border: Border.all(color: Colors.white, width: 5),
            //color: Colors.indigo[900],
            shape: BoxShape.circle,
          ),
          child: FittedBox(
            child: FloatingActionButton(
              elevation: 20,
              onPressed: () async {
                if (!(await flutterBlue.isAvailable)) {
                  showAlert(context, 'Bluetooth Not found');
                  setState(() {});
                }
                else if(!(await flutterBlue.isOn)) {
                  showAlert(context, 'Turn on Bluetooth');
                  setState(() {});
                }
                else {
                  getDevices();
                  setState(() {});
                }
              },
              child: Icon(
                Icons.bluetooth,
                size: 40,
              ),
              backgroundColor: Colors.indigo[800],
              foregroundColor: Colors.white,
            ),
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.miniCenterDocked,
      ),
    );
  }
  void showAlert(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Center(
          child: Text(
            message,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      )
    );
  }
}

